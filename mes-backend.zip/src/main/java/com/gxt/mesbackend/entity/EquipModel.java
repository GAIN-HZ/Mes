package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
/**
 * 设备型号表（t_equip_model）
 */
@Data
@TableName("t_equip_model")
public class EquipModel {
    @TableId
    private String modelCode;    // 设备型号编码（主键）
    private String modelName;    // 设备型号名称
    private String spec;         // 设备规格
    private String manageType;   // 管理类型
    private String is_valid;     // 是否有效（Y/N）
}