package com.mes.backend.equip.mapper;

import com.mes.backend.equip.entity.EquipModel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 设备型号基础信息表 Mapper 接口
 * </p>
 *
 * @author 廖晔煜
 * @since 2025-10-13
 */
public interface EquipModelMapper extends BaseMapper<EquipModel> {

}
