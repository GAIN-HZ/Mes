package com.mes.backend.equip.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mes.backend.equip.entity.EquipModel;
import com.mes.backend.equip.service.IEquipModelService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/api/equip/model")
public class EquipModelController {

    @Resource
    private IEquipModelService equipModelService;

    // 1. 新增设备型号
    @PostMapping("/add")
    public String addEquipModel(@RequestBody EquipModel equipModel) {
        // 校验必填字段
        if (equipModel.getModelCode() == null || equipModel.getModelCode().trim().isEmpty()) {
            return "错误：设备型号编码不能为空";
        }
        if (equipModel.getModelName() == null || equipModel.getModelName().trim().isEmpty()) {
            return "错误：设备型号名称不能为空";
        }
        if (equipModel.getIsValid() == null || !("Y".equals(equipModel.getIsValid()) || "N".equals(equipModel.getIsValid()))) {
            return "错误：isValid必须为Y或N";
        }

        // 校验编码唯一性
        EquipModel existing = equipModelService.getByModelCode(equipModel.getModelCode());
        if (existing != null) {
            return "错误：设备型号编码" + equipModel.getModelCode() + "已存在";
        }

        // 保存数据
        equipModelService.save(equipModel);
        return "成功：新增设备型号【" + equipModel.getModelName() + "】，编码：" + equipModel.getModelCode();
    }

    // 2. 按编码查询单条
    @GetMapping("/getByCode")
    public String getByModelCode(@RequestParam String modelCode) {
        if (modelCode == null || modelCode.trim().isEmpty()) {
            return "错误：设备型号编码不能为空";
        }

        EquipModel equipModel = equipModelService.getByModelCode(modelCode);
        if (equipModel == null) {
            return "结果：未找到编码为【" + modelCode + "】的设备型号";
        }

        return "查询成功：" +
                "编码=" + equipModel.getModelCode() + "，" +
                "名称=" + equipModel.getModelName() + "，" +
                "规格=" + equipModel.getSpec() + "，" +
                "是否有效=" + equipModel.getIsValid();
    }

    // 3. 分页查询列表
    @GetMapping("/getPage")
    public String getPageList(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String modelName
    ) {
        Page<EquipModel> page = new Page<>(pageNum, pageSize);
        IPage<EquipModel> pageResult = equipModelService.getPageList(page, modelName);

        StringBuilder result = new StringBuilder();
        result.append("分页查询结果：").append("\n")
                .append("当前页码：").append(pageNum).append("\n")
                .append("每页条数：").append(pageSize).append("\n")
                .append("总条数：").append(pageResult.getTotal()).append("\n")
                .append("总页数：").append(pageResult.getPages()).append("\n")
                .append("数据列表：").append("\n");

        // 显式声明List类型（Java 8兼容）
        List<EquipModel> records = pageResult.getRecords();
        for (EquipModel model : records) {
            result.append("编码：").append(model.getModelCode())
                    .append("，名称：").append(model.getModelName())
                    .append("，是否有效：").append(model.getIsValid()).append("\n");
        }
        return result.toString();
    }

    // 4. 修改设备型号
    @PostMapping("/update")
    public String updateEquipModel(@RequestBody EquipModel equipModel) {
        if (equipModel.getModelCode() == null || equipModel.getModelCode().trim().isEmpty()) {
            return "错误：设备型号编码（modelCode）不能为空";
        }

        boolean hasUpdateField = false;
        if (equipModel.getModelName() != null && !equipModel.getModelName().trim().isEmpty()) {
            hasUpdateField = true;
        } else if (equipModel.getSpec() != null) {
            hasUpdateField = true;
        } else if (equipModel.getManageType() != null) {
            hasUpdateField = true;
        } else if (equipModel.getIsValid() != null && ("Y".equals(equipModel.getIsValid()) || "N".equals(equipModel.getIsValid()))) {
            hasUpdateField = true;
        }
        if (!hasUpdateField) {
            return "错误：至少需要修改一个字段（名称/规格/管理类型/是否有效）";
        }

        boolean updateSuccess = equipModelService.updateEquipModel(equipModel);
        if (updateSuccess) {
            return "成功：已修改编码为【" + equipModel.getModelCode() + "】的设备型号";
        } else {
            return "错误：未找到编码为【" + equipModel.getModelCode() + "】的设备型号";
        }
    }

    // 5. 逻辑删除
    @GetMapping("/delete")
    public String deleteEquipModel(@RequestParam String modelCode) {
        if (modelCode == null || modelCode.trim().isEmpty()) {
            return "错误：设备型号编码不能为空";
        }

        boolean deleteSuccess = equipModelService.deleteEquipModel(modelCode);
        if (deleteSuccess) {
            return "成功：已将编码为【" + modelCode + "】的设备型号标记为无效";
        } else {
            return "错误：未找到编码为【" + modelCode + "】的设备型号";
        }
    }
}
