package com.mes.backend.equip.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 设备型号基础信息表
 * </p>
 *
 * @author 廖晔煜
 * @since 2025-10-13
 */
@Getter
@Setter
@TableName("t_equip_model")
@ApiModel(value = "EquipModel对象", description = "设备型号基础信息表")
public class EquipModel implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("设备型号编码（主键）")
    @TableId("model_code")
    private String modelCode;

    @ApiModelProperty("设备型号名称（如“CM602”“BM”）")
    @TableField("model_name")
    private String modelName;

    @ApiModelProperty("设备规格")
    @TableField("spec")
    private String spec;

    @ApiModelProperty("管理类型")
    @TableField("manage_type")
    private String manageType;

    @ApiModelProperty("是否有效（Y/N）")
    @TableField("is_valid")
    private String isValid;
}
