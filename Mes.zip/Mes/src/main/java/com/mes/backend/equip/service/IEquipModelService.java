package com.mes.backend.equip.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.mes.backend.equip.entity.EquipModel;

public interface IEquipModelService extends IService<EquipModel> {
    // 已有方法（新增、查询）
    EquipModel getByModelCode(String modelCode);
    IPage<EquipModel> getPageList(Page<EquipModel> page, String modelName);

    // 新增：修改设备型号
    boolean updateEquipModel(EquipModel equipModel);

    // 新增：逻辑删除设备型号
    boolean deleteEquipModel(String modelCode);
}