package com.mes.backend.generator;

import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.engine.VelocityTemplateEngine;
import java.util.Collections;

public class EquipModelGenerator {
    public static void main(String[] args) {
        // 1. 数据库连接配置（修改为你的MySQL密码）
        String url = "jdbc:mysql://localhost:3306/mes_db?serverTimezone=UTC&useUnicode=true&characterEncoding=utf-8";
        String username = "root";  // 你的MySQL用户名（默认root）
        String password = "12345";// 你的MySQL密码（建库时用的密码）

        // 2. 代码输出路径（修改为你的项目src/main/java绝对路径）
        // 示例：从IDEA项目面板右键src/main/java→"Open in Explorer"，复制路径
        String outputDir = "F:\\Mes_homework\\Mes\\src\\main\\java";
        // Mapper.xml输出路径（资源文件夹下的equip子目录，避免与其他表混淆）
        String xmlOutputDir = "F:\\Mes_homework\\Mes\\src\\main\\resources\\mapper\\equip";

        // 3. 生成t_equip_model表的代码
        FastAutoGenerator.create(url, username, password)
                .globalConfig(builder -> {
                    builder.author("廖晔煜")  // 实验报告需填的开发者姓名
                            .outputDir(outputDir)
                            .enableSwagger()  // 支持接口文档（后续联调有用）
                            .commentDate("yyyy-MM-dd");
                })
                .packageConfig(builder -> {
                    builder.parent("com.mes.backend")  // 根包（之前手动创建的com.mes.backend）
                            .moduleName("equip")  // 设备模块代码放equip子包，结构清晰
                            .entity("entity")      // 实体类（对应t_equip_model字段）
                            .mapper("mapper")      // 数据访问接口
                            .service("service")    // 业务逻辑接口
                            .serviceImpl("service.impl")  // 业务实现类
                            .controller("controller")    // 接口控制器
                            .xml("mapper")
                            .pathInfo(Collections.singletonMap(OutputFile.xml, xmlOutputDir));
                })
                .strategyConfig(builder -> {
                    builder.addInclude("t_equip_model")  // 仅生成设备型号表代码（精准匹配建库表名）
                            .addTablePrefix("t_")  // 去掉表前缀"t_"，生成实体类名EquipModel（而非TEquipModel）
                            .entityBuilder()
                            .enableLombok()  // 用Lombok简化实体类（无需写get/set方法）
                            .enableTableFieldAnnotation()  // 给字段加注释（对应建库SQL的COMMENT）
                            .controllerBuilder()
                            .enableRestStyle();  // 生成@RestController（返回JSON，适配前端）
                })
                .templateEngine(new VelocityTemplateEngine())
                .execute();
    }
}