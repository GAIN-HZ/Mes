package com.mes.backend.equip.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mes.backend.equip.entity.EquipModel;
import com.mes.backend.equip.mapper.EquipModelMapper;
import com.mes.backend.equip.service.IEquipModelService;
import org.springframework.stereotype.Service;

@Service
public class EquipModelServiceImpl extends ServiceImpl<EquipModelMapper, EquipModel> implements IEquipModelService {

    // 1. 按编码查询：直接用QueryWrapper匹配model_code
    @Override
    public EquipModel getByModelCode(String modelCode) {
        QueryWrapper<EquipModel> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("model_code", modelCode.trim()); // 去除空格，避免查询误差
        return baseMapper.selectOne(queryWrapper);
    }

    // 2. 分页查询：支持按型号名称模糊搜索，若名称为空则查所有
    @Override
    public IPage<EquipModel> getPageList(Page<EquipModel> page, String modelName) {
        QueryWrapper<EquipModel> queryWrapper = new QueryWrapper<>();
        if (modelName != null && !modelName.trim().isEmpty()) {
            queryWrapper.like("model_name", modelName.trim()); // 模糊匹配（如输入“CM”能查到“CM602”）
        }
        // 按型号编码升序排序，结果更规整
        queryWrapper.orderByAsc("model_code");
        return baseMapper.selectPage(page, queryWrapper);
    }

    // 3. 实现修改设备型号方法
    @Override
    public boolean updateEquipModel(EquipModel equipModel) {
        // 校验该型号是否存在
        EquipModel existingModel = getByModelCode(equipModel.getModelCode());
        if (existingModel == null) {
            return false; // 型号不存在，修改失败
        }

        // 仅更新非空字段
        if (equipModel.getModelName() != null && !equipModel.getModelName().trim().isEmpty()) {
            existingModel.setModelName(equipModel.getModelName().trim());
        }
        if (equipModel.getSpec() != null) {
            existingModel.setSpec(equipModel.getSpec().trim());
        }
        if (equipModel.getManageType() != null) {
            existingModel.setManageType(equipModel.getManageType().trim());
        }
        if (equipModel.getIsValid() != null && ("Y".equals(equipModel.getIsValid()) || "N".equals(equipModel.getIsValid()))) {
            existingModel.setIsValid(equipModel.getIsValid().trim());
        }

        // 执行更新操作
        return updateById(existingModel);
    }

    // 4. 实现逻辑删除设备型号方法
    @Override
    public boolean deleteEquipModel(String modelCode) {
        // 校验该型号是否存在
        EquipModel existingModel = getByModelCode(modelCode);
        if (existingModel == null) {
            return false; // 型号不存在，删除失败
        }

        // 若已无效，直接返回成功
        if ("N".equals(existingModel.getIsValid())) {
            return true;
        }

        // 执行逻辑删除：将is_valid改为N
        existingModel.setIsValid("N");
        return updateById(existingModel);
    }
}
