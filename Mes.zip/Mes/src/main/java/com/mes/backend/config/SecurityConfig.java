package com.mes.backend.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * Spring Security配置类
 * 作用：控制哪些接口需要认证，哪些可以匿名访问
 */
@Configuration  // 标记为配置类
@EnableWebSecurity  // 启用Web安全功能
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    /**
     * 配置HTTP安全规则
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                // 关闭CSRF保护（开发环境简化配置，生产环境需开启）
                .csrf().disable()
                // 配置请求授权规则
                .authorizeRequests()
                // 允许所有设备型号相关接口匿名访问
                .antMatchers("/api/equip/model/**").permitAll()
                // 允许Swagger接口文档匿名访问（后续会用到）
                .antMatchers("/swagger-ui.html", "/swagger-resources/**", "/v2/api-docs", "/webjars/**").permitAll()
                // 其他所有请求需要认证
                .anyRequest().authenticated()
                .and()
                // 配置表单登录（默认提供一个登录页面）
                .formLogin()
                // 登录页面地址（默认是/spring-security-login）
                .loginPage("/login")
                // 登录成功后的跳转地址（这里简化处理，实际项目可根据需求修改）
                .defaultSuccessUrl("/")
                .permitAll()  // 允许所有人访问登录页面
                .and()
                // 配置退出登录
                .logout()
                .permitAll();  // 允许所有人访问退出功能
    }
}
