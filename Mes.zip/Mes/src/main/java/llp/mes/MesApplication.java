package llp.mes;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"llp.mes", "com.mes.backend"}) // 扫描Controller等组件
@MapperScan("com.mes.backend.equip.mapper") // 关键：扫描Mapper接口所在包
public class MesApplication {
    public static void main(String[] args) {
        SpringApplication.run(MesApplication.class, args);
    }
}