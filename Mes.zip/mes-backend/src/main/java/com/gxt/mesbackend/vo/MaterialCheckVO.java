package com.gxt.mesbackend.vo;

public class MaterialCheckVO {
}
