package com.gxt.mesbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.ProductionExecution;
import com.gxt.mesbackend.common.Result;

public interface ProductionExecutionService extends IService<ProductionExecution> {
    // 开始工序执行（关联生产计划）
    Result<?> startExecution(ProductionExecution execution);

    // 结束工序执行（更新产量、不良数等）
    Result<?> finishExecution(String execId, Integer actualQty, Integer ngQty);

    // 查询指定计划的执行明细
    Result<?> getExecutionsByPlan(String planCode);
}