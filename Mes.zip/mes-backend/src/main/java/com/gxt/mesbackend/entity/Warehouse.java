package com.gxt.mesbackend.entity;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
/**
 * 仓库表（t_warehouse）
 */
@Data
@TableName("t_warehouse")
public class Warehouse {
    @TableId
    private String warehouseCode; // 仓库编码（主键）
    private String warehouseName; // 仓库名称
    private String warehouseType; // 仓库类型
    private String attribute;     // 仓库属性
    private String isVirtual;     // 是否虚拟仓库（Y/N）
    private String is_valid;      // 是否有效（Y/N）
}