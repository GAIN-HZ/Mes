package com.gxt.mesbackend.service.impl;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gxt.mesbackend.entity.EquipModel;
import com.gxt.mesbackend.mapper.EquipModelMapper;
import com.gxt.mesbackend.service.EquipModelService;
import org.springframework.stereotype.Service;
@Service
public class EquipModelServiceImpl extends ServiceImpl<EquipModelMapper, EquipModel> implements EquipModelService {
}