package com.gxt.mesbackend.vo;

import lombok.Data;

@Data
public class ProductionScheduleVO {
    private String scheduleCode;       // 排产任务编码
    private String planCode;           // 生产计划编码
    private String productCode;        // 产品编码
    private String productName;        // 产品名称（关联t_product）
    private Integer planQty;           // 计划产量
    private String warehouseCode;      // 仓库编码
    private String warehouseName;      // 仓库名称
    private String status;             // 状态
}