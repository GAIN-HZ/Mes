package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("t_material_inbound_item")
public class MaterialInboundItem {
    @TableId(type = IdType.ASSIGN_UUID)
    private String itemId;             // 明细ID（主键）
    @TableField("inbound_no")
    private String inboundNo;          // 入库单号（外键关联t_material_inbound）
    @TableField("material_code")
    private String materialCode;       // 物料编码
    @TableField("inbound_qty")
    private Integer inboundQty;        // 入库数量
    @TableField("batch_no")
    private String batchNo;            // 批次号
    @TableField("unit")
    private String unit;               // 单位（个/件/包）
}
