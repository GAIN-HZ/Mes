package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("t_production_plan")
public class ProductionPlan {
    @TableId(type = IdType.INPUT) // 计划编码手动输入，非自增
    private String planCode;

    @TableField("product_code")
    private String productCode;

    @TableField("plan_qty")
    private Integer planQty;

    @TableField("start_date")
    private LocalDateTime startDate;

    @TableField("end_date")
    private LocalDateTime endDate;

    @TableField("line_code")
    private String lineCode;

    @TableField("workshop_code")
    private String workshopCode;

    @TableField("plan_status")
    private String planStatus; // 未开始/执行中/已完成/已取消

    @TableField("create_by")
    private String createBy;

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("update_by")
    private String updateBy;

    @TableField("update_time")
    private LocalDateTime updateTime;
}