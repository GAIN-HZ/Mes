package com.gxt.mesbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.EquipInfo;
public interface EquipInfoService extends IService<EquipInfo> {
}