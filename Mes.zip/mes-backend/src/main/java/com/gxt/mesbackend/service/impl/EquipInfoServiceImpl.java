package com.gxt.mesbackend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gxt.mesbackend.entity.EquipInfo;
import com.gxt.mesbackend.mapper.EquipInfoMapper;
import com.gxt.mesbackend.service.EquipInfoService;
import org.springframework.stereotype.Service;
@Service
public class EquipInfoServiceImpl extends ServiceImpl<EquipInfoMapper, EquipInfo> implements EquipInfoService {
}