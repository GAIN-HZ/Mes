package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("t_material_inventory")
public class MaterialInventory {
    @TableId(type = IdType.ASSIGN_ID)
    private String inventoryId;        // 库存记录ID（主键）
    @TableField("material_code")
    private String materialCode;       // 物料编码（关联t_material）
    @TableField("warehouse_code")
    private String warehouseCode;      // 仓库编码（关联t_warehouse）
    @TableField("loc_code")
    private String locCode;            // 储位编码（可选）
    @TableField("stock_qty")
    private Integer stockQty;          // 当前库存数量
    @TableField("safe_stock_qty")
    private Integer safeStockQty;      // 安全库存数量
    @TableField("batch_no")
    private String batchNo;            // 批次号
    @TableField("produce_date")
    private LocalDateTime produceDate; // 生产/入库日期
    @TableField("expire_date")
    private LocalDateTime expireDate;  // 过期日期
    @TableField("inventory_status")
    private String inventoryStatus;    // 库存状态（可用/冻结/待检）
    @TableField("update_time")
    private LocalDateTime updateTime;  // 最后更新时间
}
