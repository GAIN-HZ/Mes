package com.gxt.mesbackend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gxt.mesbackend.entity.MaterialOutbound;
import com.gxt.mesbackend.entity.MaterialOutboundItem;
import com.gxt.mesbackend.entity.ProductionSchedule;
import com.gxt.mesbackend.mapper.MaterialOutboundItemMapper;
import com.gxt.mesbackend.mapper.MaterialOutboundMapper;
import com.gxt.mesbackend.service.MaterialInventoryService;
import com.gxt.mesbackend.service.MaterialOutboundService;
import com.gxt.mesbackend.service.ProductionScheduleService;
import com.gxt.mesbackend.vo.MaterialOutboundVO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MaterialOutboundServiceImpl extends ServiceImpl<MaterialOutboundMapper, MaterialOutbound>
        implements MaterialOutboundService {

    @Resource
    private MaterialOutboundMapper outboundMapper;
    @Resource
    private MaterialOutboundItemMapper itemMapper;
    @Resource
    private ProductionScheduleService scheduleService;
    @Resource
    private MaterialInventoryService inventoryService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createProductionOutbound(String scheduleCode) {
        // 1. 查询排产任务
        ProductionSchedule schedule = scheduleService.getById(scheduleCode);
        if (schedule == null) {
            throw new RuntimeException("排产任务不存在");
        }

        // 2. 生成出库单
        MaterialOutbound outbound = new MaterialOutbound();
        outbound.setOutboundNo(generateOutboundCode()); // 复用编码生成工具
        outbound.setSourceType("生产领料");
        outbound.setSourceNo(schedule.getPlanCode());
        outbound.setWarehouseCode(schedule.getWarehouseCode());
        outbound.setStatus("草稿");
        outboundMapper.insert(outbound);

        // 3. 生成出库明细（模拟BOM物料）
        // 实际场景需关联BOM表查询物料清单
        MaterialOutboundItem item = new MaterialOutboundItem();
        item.setOutboundNo(outbound.getOutboundNo());
        item.setMaterialCode(schedule.getProductCode()); // 简化：用产品编码代替物料编码
        item.setOutboundQty(schedule.getPlanQty());
        item.setScheduleCode(scheduleCode);
        itemMapper.insert(item);

        // 4. 扣减库存
        inventoryService.deductStock(schedule.getProductCode(), schedule.getWarehouseCode(), schedule.getPlanQty());

        // 5. 更新出库单状态
        outbound.setStatus("已确认");
        outboundMapper.updateById(outbound);
    }

    @Override
    public PageInfo<MaterialOutboundVO> queryPage(String outboundNo, String sourceType, Integer pageNum, Integer pageSize) {
        // 1. 初始化分页
        PageHelper.startPage(pageNum, pageSize);

        // 2. 构造查询条件
        LambdaQueryWrapper<MaterialOutbound> wrapper = new LambdaQueryWrapper<>();
        if (outboundNo != null && !outboundNo.isEmpty()) {
            wrapper.like(MaterialOutbound::getOutboundNo, outboundNo);
        }
        if (sourceType != null && !sourceType.isEmpty()) {
            wrapper.eq(MaterialOutbound::getSourceType, sourceType);
        }
        //wrapper.orderByDesc(MaterialOutbound::getCreateTime);

        // 3. 查询数据并转换为VO
        List<MaterialOutbound> list = outboundMapper.selectList(wrapper);
        List<MaterialOutboundVO> voList = list.stream().map(item -> {
            MaterialOutboundVO vo = new MaterialOutboundVO();
            BeanUtils.copyProperties(item, vo);
            return vo;
        }).collect(Collectors.toList());

        // 4. 封装分页结果
        return new PageInfo<>(voList);
    }

    @Override
    public void confirmOutbound(String outboundNo) {

    }

    // 复用生产管理的编码生成规则
    private String generateOutboundCode() {
        // 1. 生成前缀（年月）
        String prefix = "OUT" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMM"));
        // 2. 调用selectMaxCode时传入prefix参数
        Integer maxCode = outboundMapper.selectMaxCode(prefix);
        // 3. 计算序号
        int seq = (maxCode == null) ? 1 : maxCode + 1;
        // 4. 拼接出库单号
        return prefix + String.format("%05d", seq);
    }
}