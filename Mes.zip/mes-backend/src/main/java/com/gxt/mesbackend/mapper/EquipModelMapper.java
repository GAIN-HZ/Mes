package com.gxt.mesbackend.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.EquipModel;
import org.apache.ibatis.annotations.Mapper;
@Mapper
public interface EquipModelMapper extends BaseMapper<EquipModel> {
}