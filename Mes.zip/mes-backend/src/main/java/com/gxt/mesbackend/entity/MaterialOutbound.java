package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("t_material_outbound")
public class MaterialOutbound {
    @TableId(type = IdType.INPUT)
    private String outboundNo;         // 出库单号（主键：OUT+年月+流水号）
    @TableField("source_type")
    private String sourceType;         // 出库用途（生产领料/销售/报废）
    @TableField("source_no")
    private String sourceNo;           // 来源单号（生产计划号/排产任务号）
    @TableField("warehouse_code")
    private String warehouseCode;      // 出库仓库编码
    @TableField("outbound_time")
    private LocalDateTime outboundTime;// 出库时间
    @TableField("operator")
    private String operator;           // 操作员
    @TableField("status")
    private String status;             // 状态（草稿/已确认/已取消）
    @TableField("remark")
    private String remark;             // 备注


}
