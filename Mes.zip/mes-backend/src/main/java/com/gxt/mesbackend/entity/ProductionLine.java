package com.gxt.mesbackend.entity;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
/**
 * 产线表（t_production_line）
 */
@Data
@TableName("t_production_line")
public class ProductionLine {
    @TableId
    private String lineCode;             // 产线编码（主键）
    private String lineName;             // 产线名称
    private String workshopCode;         // 车间编码（外键）
    private String processSectionCode;   // 工艺段编码
    private String lineType;             // 产线类型（SMT/通用）
    private String is_valid;             // 是否有效（Y/N）
}