package com.gxt.mesbackend.entity;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
/**
 * 车间表（t_workshop）
 */
@Data
@TableName("t_workshop")
public class Workshop {
    @TableId
    private String workshopCode; // 车间编码（主键）
    private String workshopName; // 车间名称
    private String is_valid;     // 是否有效（Y/N）
}