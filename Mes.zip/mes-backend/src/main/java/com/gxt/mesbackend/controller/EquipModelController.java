package com.gxt.mesbackend.controller;
import com.gxt.mesbackend.common.Result;
import com.gxt.mesbackend.entity.EquipModel;
import com.gxt.mesbackend.service.EquipModelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/**
 * 设备型号管理接口
 */
@RestController
@RequestMapping("/basic/equip-model")
public class EquipModelController {
    @Autowired
    private EquipModelService equipModelService;
    /**
     * 新增设备型号
     */
    @PostMapping("/add")
    public Result<?> add(@RequestBody EquipModel equipModel) {
        boolean saved = equipModelService.save(equipModel);
        return saved ? Result.success() : Result.fail("新增失败");
    }
    /**
     * 删除设备型号
     */
    @DeleteMapping("/{modelCode}")
    public Result<?> delete(@PathVariable String modelCode) {
        boolean removed = equipModelService.removeById(modelCode);
        return removed ? Result.success() : Result.fail("删除失败");
    }
    /**
     * 更新设备型号
     */
    @PutMapping("/update")
    public Result<?> update(@RequestBody EquipModel equipModel) {
        boolean updated = equipModelService.updateById(equipModel);
        return updated ? Result.success() : Result.fail("更新失败");
    }
    /**
     * 查询所有设备型号
     */
    @GetMapping("/list")
    public Result<List<EquipModel>> list() {
        return Result.success(equipModelService.list());
    }
}