package com.gxt.mesbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.EquipModel;
public interface EquipModelService extends IService<EquipModel> {
}
