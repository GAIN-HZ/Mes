package com.gxt.mesbackend.vo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class MaterialOutboundVO {
    private String outboundNo;         // 出库单号
    private String sourceType;         // 出库用途
    private String sourceNo;           // 来源单号
    private String warehouseCode;      // 仓库编码
    private String warehouseName;      // 仓库名称
    private LocalDateTime outboundTime;// 出库时间
    private String operator;           // 操作员
    private String status;             // 状态
}