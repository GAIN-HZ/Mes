package com.gxt.mesbackend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gxt.mesbackend.entity.Department;
import com.gxt.mesbackend.mapper.DepartmentMapper;
import com.gxt.mesbackend.service.DepartmentService;
import org.springframework.stereotype.Service;
@Service
public class DepartmentServiceImpl extends ServiceImpl<DepartmentMapper, Department> implements DepartmentService {
}