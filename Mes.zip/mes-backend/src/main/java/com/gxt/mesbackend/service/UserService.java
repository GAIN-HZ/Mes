package com.gxt.mesbackend.service;
import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.User;
public interface UserService extends IService<User> {
}