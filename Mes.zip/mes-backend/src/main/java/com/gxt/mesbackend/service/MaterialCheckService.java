package com.gxt.mesbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.MaterialCheck;
import com.gxt.mesbackend.vo.MaterialCheckVO;
import com.github.pagehelper.PageInfo;

public interface MaterialCheckService extends IService<MaterialCheck> {
    // 盘点单分页查询
    PageInfo<MaterialCheckVO> queryPage(String checkNo, String warehouseCode, Integer pageNum, Integer pageSize);

    // 确认盘点并调整库存
    void confirmCheck(String checkNo);
}
