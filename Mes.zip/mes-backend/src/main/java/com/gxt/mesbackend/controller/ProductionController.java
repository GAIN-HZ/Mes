package com.gxt.mesbackend.controller;

import com.gxt.mesbackend.entity.ProductionPlan;
import com.gxt.mesbackend.entity.ProductionExecution;
import com.gxt.mesbackend.service.ProductionPlanService;
import com.gxt.mesbackend.service.ProductionExecutionService;
import com.gxt.mesbackend.common.Result;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/mes/production")
public class ProductionController {

    @Resource
    private ProductionPlanService planService;

    @Resource
    private ProductionExecutionService executionService;

    // 生产计划相关接口
    @PostMapping("/plan")
    public Result<?> createPlan(@RequestBody ProductionPlan plan) {
        return planService.createPlan(plan);
    }

    @PutMapping("/plan/status")
    public Result<?> updatePlanStatus(@RequestParam String planCode, @RequestParam String status) {
        return planService.updatePlanStatus(planCode, status);
    }

    @GetMapping("/plan/line")
    public Result<?> getPlansByLine(@RequestParam String lineCode, @RequestParam(required = false) String status) {
        return planService.getPlansByLine(lineCode, status);
    }

    // 生产执行相关接口
    @PostMapping("/execution/start")
    public Result<?> startExecution(@RequestBody ProductionExecution execution) {
        return executionService.startExecution(execution);
    }

    @PutMapping("/execution/finish")
    public Result<?> finishExecution(
            @RequestParam String execId,
            @RequestParam Integer actualQty,
            @RequestParam Integer ngQty
    ) {
        return executionService.finishExecution(execId, actualQty, ngQty);
    }

    @GetMapping("/execution/plan")
    public Result<?> getExecutionsByPlan(@RequestParam String planCode) {
        return executionService.getExecutionsByPlan(planCode);
    }
}