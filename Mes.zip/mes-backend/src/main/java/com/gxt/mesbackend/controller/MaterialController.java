package com.gxt.mesbackend.controller;
import com.gxt.mesbackend.common.Result;
import com.gxt.mesbackend.entity.Material;
import com.gxt.mesbackend.service.MaterialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/**
 * 物料管理接口
 */
@RestController
@RequestMapping("/basic/material")
public class MaterialController {
    @Autowired
    private MaterialService materialService;
    /**
     * 新增物料
     */
    @PostMapping("/add")
    public Result<?> add(@RequestBody Material material) {
        boolean saved = materialService.save(material);
        return saved ? Result.success() : Result.fail("新增失败");
    }
    /**
     * 删除物料
     */
    @DeleteMapping("/{materialCode}")
    public Result<?> delete(@PathVariable String materialCode) {
        boolean removed = materialService.removeById(materialCode);
        return removed ? Result.success() : Result.fail("删除失败");
    }
    /**
     * 更新物料
     */
    @PutMapping("/update")
    public Result<?> update(@RequestBody Material material) {
        boolean updated = materialService.updateById(material);
        return updated ? Result.success() : Result.fail("更新失败");
    }
    /**
     * 查询所有物料
     */
    @GetMapping("/list")
    public Result<List<Material>> list() {
        return Result.success(materialService.list());
    }
    /**
     * 根据物料编码查询
     */
    @GetMapping("/{materialCode}")
    public Result<Material> getById(@PathVariable String materialCode) {
        Material material = materialService.getById(materialCode);
        return material != null ? Result.success(material) : Result.fail("物料不存在");
    }
}