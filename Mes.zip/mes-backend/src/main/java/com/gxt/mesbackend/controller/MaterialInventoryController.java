package com.gxt.mesbackend.controller;

import com.github.pagehelper.PageInfo;
import com.gxt.mesbackend.common.Result;
import com.gxt.mesbackend.service.MaterialInventoryService;
import com.gxt.mesbackend.vo.MaterialInventoryVO;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;

@RestController
@RequestMapping("/material/inventory")
public class MaterialInventoryController {

    @Resource
    private MaterialInventoryService inventoryService;

    @GetMapping("/query")
    public Result<PageInfo<MaterialInventoryVO>> query(
            @RequestParam(required = false) String materialCode,
            @RequestParam(required = false) String warehouseCode,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        return Result.success(inventoryService.queryPage(materialCode, warehouseCode, pageNum, pageSize));
    }

    @GetMapping("/warning")
    public Result<PageInfo<MaterialInventoryVO>> warning(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        return Result.success(inventoryService.queryWarningInventory(pageNum, pageSize));
    }

    @PostMapping("/addStock")
    public Result<?> addStock(
            @RequestParam String materialCode,
            @RequestParam String warehouseCode,
            @RequestParam Integer qty) {
        inventoryService.addStock(materialCode, warehouseCode, qty);
        return Result.success();
    }

    @PostMapping("/deductStock")
    public Result<?> deductStock(
            @RequestParam String materialCode,
            @RequestParam String warehouseCode,
            @RequestParam Integer qty) {
        inventoryService.deductStock(materialCode, warehouseCode, qty);
        return Result.success();
    }
}