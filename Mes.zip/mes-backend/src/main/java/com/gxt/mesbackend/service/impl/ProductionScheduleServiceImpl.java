package com.gxt.mesbackend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gxt.mesbackend.entity.ProductionSchedule;
import com.gxt.mesbackend.mapper.ProductionScheduleMapper;
import com.gxt.mesbackend.service.ProductionScheduleService;
import com.gxt.mesbackend.vo.ProductionScheduleVO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductionScheduleServiceImpl extends ServiceImpl<ProductionScheduleMapper, ProductionSchedule>
        implements ProductionScheduleService {

    @Resource
    private ProductionScheduleMapper scheduleMapper;

    @Override
    public PageInfo<ProductionScheduleVO> queryPage(String scheduleCode, String planCode, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);

        // 修复1：使用LambdaQueryWrapper替代QueryWrapper.lambda()（避免静态上下文调用非静态方法）
        LambdaQueryWrapper<ProductionSchedule> wrapper = new LambdaQueryWrapper<>();
        if (scheduleCode != null && !scheduleCode.isEmpty()) {
            wrapper.like(ProductionSchedule::getScheduleCode, scheduleCode);
        }
        if (planCode != null && !planCode.isEmpty()) {
            wrapper.eq(ProductionSchedule::getPlanCode, planCode);
        }

        List<ProductionSchedule> list = scheduleMapper.selectList(wrapper);
        List<ProductionScheduleVO> voList = list.stream().map(item -> {
            ProductionScheduleVO vo = new ProductionScheduleVO();
            BeanUtils.copyProperties(item, vo);
            return vo;
        }).collect(Collectors.toList());
        return new PageInfo<>(voList);
    }

    @Override
    public ProductionSchedule getByScheduleCode(String scheduleCode) {
        // 修复2：getByScheduleCode应是根据scheduleCode查询，而非selectById（selectById是根据主键ID查询）
        LambdaQueryWrapper<ProductionSchedule> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ProductionSchedule::getScheduleCode, scheduleCode);
        return scheduleMapper.selectOne(wrapper);
    }

    @Override
    public List<ProductionSchedule> getByPlanCode(String planCode) {
        // 修复3：统一使用LambdaQueryWrapper
        LambdaQueryWrapper<ProductionSchedule> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ProductionSchedule::getPlanCode, planCode);
        return scheduleMapper.selectList(wrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createSchedule(ProductionSchedule schedule) {
        scheduleMapper.insert(schedule);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStatus(String scheduleCode, String status) {
        ProductionSchedule schedule = getByScheduleCode(scheduleCode);
        if (schedule == null) {
            throw new RuntimeException("排产任务不存在");
        }
        schedule.setStatus(status);
        scheduleMapper.updateById(schedule);
    }
}