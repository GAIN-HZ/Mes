package com.gxt.mesbackend.entity;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.util.Date;
/**
 * 设备信息表（t_equip_info）
 */
@Data
@TableName("t_equip_info")
public class EquipInfo {
    @TableId
    private String equipCode;        // 设备编码（主键）
    private String modelCode;        // 设备型号编码（外键）
    private String workshopCode;     // 车间编码（外键）
    private String lineCode;         // 产线编码（外键）
    private String status;           // 设备状态（运行/停机/维修）
    private Date purchaseDate;       // 采购日期
    private Date lastMaintainDate;   // 上次维护日期
}