package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("t_material_outbound_item")
public class MaterialOutboundItem {
    @TableId(type = IdType.ASSIGN_UUID)
    private String itemId;             // 明细ID（主键）
    @TableField("outbound_no")
    private String outboundNo;         // 出库单号（外键关联t_material_outbound）
    @TableField("material_code")
    private String materialCode;       // 物料编码
    @TableField("outbound_qty")
    private Integer outboundQty;       // 出库数量
    @TableField("batch_no")
    private String batchNo;            // 批次号
    @TableField("unit")
    private String unit;               // 单位（个/件/包）
    @TableField("schedule_code")
    private String scheduleCode;       // 关联排产任务号（可选）
}
