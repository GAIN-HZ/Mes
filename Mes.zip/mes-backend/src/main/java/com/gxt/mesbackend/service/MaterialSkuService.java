package com.gxt.mesbackend.service;
import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.MaterialSku;
public interface MaterialSkuService extends IService<MaterialSku> {
}