package com.gxt.mesbackend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gxt.mesbackend.entity.Material;
import com.gxt.mesbackend.mapper.MaterialMapper;
import com.gxt.mesbackend.service.MaterialService;
import org.springframework.stereotype.Service;
@Service
public class MaterialServiceImpl extends ServiceImpl<MaterialMapper, Material> implements MaterialService {
}