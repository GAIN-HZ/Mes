package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;
@Data // Lombok注解自动生成Getter/Setter、toString等方法
@TableName("t_production_schedule")
public class ProductionSchedule {
    @TableId(type = IdType.INPUT)
    private String scheduleCode;       // 排产任务编码（主键）

    @TableField("plan_code")
    private String planCode;           // 关联生产计划编码

    @TableField("product_code")
    private String productCode;        // 产品编码

    @TableField("plan_qty")
    private Integer planQty;           // 计划产量

    @TableField("warehouse_code")
    private String warehouseCode;      // 生产仓库编码

    @TableField("start_time")
    private LocalDateTime startTime;   // 开始时间

    @TableField("end_time")
    private LocalDateTime endTime;     // 结束时间

    @TableField("status")
    private String status;             // 状态（排产中/生产中/已完成）

    @TableField("create_time")
    private LocalDateTime createTime;  // 创建时间

    @TableField("create_user")
    private String createUser;         // 创建人
}