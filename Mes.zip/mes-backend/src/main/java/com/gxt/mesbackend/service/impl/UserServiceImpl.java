package com.gxt.mesbackend.service.impl;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gxt.mesbackend.entity.User;
import com.gxt.mesbackend.mapper.UserMapper;
import com.gxt.mesbackend.service.UserService;
import org.springframework.stereotype.Service;
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
}