package com.gxt.mesbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.MaterialOutbound;
import com.gxt.mesbackend.vo.MaterialOutboundVO;
import com.github.pagehelper.PageInfo;

public interface MaterialOutboundService extends IService<MaterialOutbound> {
    // 生产领料出库（关联排产任务）
    void createProductionOutbound(String scheduleCode);

    // 出库单分页查询
    PageInfo<MaterialOutboundVO> queryPage(String outboundNo, String sourceType, Integer pageNum, Integer pageSize);

    // 确认出库（扣减库存）
    void confirmOutbound(String outboundNo);
}
