package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.MaterialCheck;

public interface MaterialCheckMapper extends BaseMapper<MaterialCheck> {
}