package com.gxt.mesbackend.service.impl;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gxt.mesbackend.entity.MaterialSku;
import com.gxt.mesbackend.mapper.MaterialSkuMapper;
import com.gxt.mesbackend.service.MaterialSkuService;
import org.springframework.stereotype.Service;
@Service
public class MaterialSkuServiceImpl extends ServiceImpl<MaterialSkuMapper, MaterialSku> implements MaterialSkuService {
}