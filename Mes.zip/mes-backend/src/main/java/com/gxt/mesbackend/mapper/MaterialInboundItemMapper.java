package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.MaterialInboundItem;

public interface MaterialInboundItemMapper extends BaseMapper<MaterialInboundItem> {
}