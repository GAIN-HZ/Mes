package com.gxt.mesbackend.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.Department;
import org.apache.ibatis.annotations.Mapper;
@Mapper
public interface DepartmentMapper extends BaseMapper<Department> {
}