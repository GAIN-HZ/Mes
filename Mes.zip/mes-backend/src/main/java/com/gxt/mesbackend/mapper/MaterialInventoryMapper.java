package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.MaterialInventory;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface MaterialInventoryMapper extends BaseMapper<MaterialInventory> {
    // 库存预警查询（低于安全库存）
    List<MaterialInventory> selectWarningInventory();

    // 按物料+仓库查询库存
    MaterialInventory selectByMaterialAndWarehouse(@Param("materialCode") String materialCode,
                                                   @Param("warehouseCode") String warehouseCode);
}
