package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.MaterialInbound;

public interface MaterialInboundMapper extends BaseMapper<MaterialInbound> {
}