package com.gxt.mesbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.MaterialInventory;
import com.gxt.mesbackend.vo.MaterialInventoryVO;
import com.github.pagehelper.PageInfo;

public interface MaterialInventoryService extends IService<MaterialInventory> {
    // 库存分页查询
    PageInfo<MaterialInventoryVO> queryPage(String materialCode, String warehouseCode, Integer pageNum, Integer pageSize);

    // 库存预警查询
    PageInfo<MaterialInventoryVO> queryWarningInventory(Integer pageNum, Integer pageSize);

    // 扣减库存（生产领料/出库）
    void deductStock(String materialCode, String warehouseCode, Integer qty);

    // 增加库存（入库/退货）
    void addStock(String materialCode, String warehouseCode, Integer qty);
}
