package com.gxt.mesbackend.controller;
import com.gxt.mesbackend.common.Result;
import com.gxt.mesbackend.entity.User;
import com.gxt.mesbackend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/**
 * 员工管理接口
 */
@RestController
@RequestMapping("/basic/user")
public class UserController {
    @Autowired
    private UserService userService;
    /**
     * 新增员工
     */
    @PostMapping("/add")
    public Result<?> add(@RequestBody User user) {
        boolean saved = userService.save(user);
        return saved ? Result.success() : Result.fail("新增失败");
    }
    /**
     * 删除员工
     */
    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Integer id) {
        boolean removed = userService.removeById(id);
        return removed ? Result.success() : Result.fail("删除失败");
    }
    /**
     * 更新员工
     */
    @PutMapping("/update")
    public Result<?> update(@RequestBody User user) {
        boolean updated = userService.updateById(user);
        return updated ? Result.success() : Result.fail("更新失败");
    }
    /**
     * 查询所有员工
     */
    @GetMapping("/list")
    public Result<List<User>> list() {
        return Result.success(userService.list());
    }
    /**
     * 根据ID查询员工
     */
    @GetMapping("/{id}")
    public Result<User> getById(@PathVariable Integer id) {
        User user = userService.getById(id);
        return user != null ? Result.success(user) : Result.fail("员工不存在");
    }
}