package com.gxt.mesbackend.entity;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
/**
 * 部门表（t_department）
 */
@Data
@TableName("t_department")
public class Department {
    @TableId
    private String deptCode;       // 部门编码（主键）
    private String deptName;       // 部门名称
    private String parentDeptCode; // 父部门编码
    private String workshopCode;   // 所属车间编码
    private String is_valid;       // 是否有效（Y/N）
}