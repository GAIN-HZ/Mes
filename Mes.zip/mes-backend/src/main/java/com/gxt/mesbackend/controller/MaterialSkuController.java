package com.gxt.mesbackend.controller;
import com.gxt.mesbackend.common.Result;
import com.gxt.mesbackend.entity.MaterialSku;
import com.gxt.mesbackend.service.MaterialSkuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/**
 * 物料SKU管理接口
 */
@RestController
@RequestMapping("/basic/material-sku")
public class MaterialSkuController {
    @Autowired
    private MaterialSkuService materialSkuService;
    /**
     * 新增SKU
     */
    @PostMapping("/add")
    public Result<?> add(@RequestBody MaterialSku materialSku) {
        boolean saved = materialSkuService.save(materialSku);
        return saved ? Result.success() : Result.fail("新增失败");
    }
    /**
     * 删除SKU
     */
    @DeleteMapping("/{skuCode}")
    public Result<?> delete(@PathVariable String skuCode) {
        boolean removed = materialSkuService.removeById(skuCode);
        return removed ? Result.success() : Result.fail("删除失败");
    }
    /**
     * 更新SKU
     */
    @PutMapping("/update")
    public Result<?> update(@RequestBody MaterialSku materialSku) {
        boolean updated = materialSkuService.updateById(materialSku);
        return updated ? Result.success() : Result.fail("更新失败");
    }
    /**
     * 查询所有SKU
     */
    @GetMapping("/list")
    public Result<List<MaterialSku>> list() {
        return Result.success(materialSkuService.list());
    }
}