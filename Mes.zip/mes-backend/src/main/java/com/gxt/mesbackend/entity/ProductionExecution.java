package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("t_production_execution")
public class ProductionExecution {
    @TableId(type = IdType.ASSIGN_UUID) // 执行记录ID自动生成UUID
    private String execId;

    @TableField("plan_code")
    private String planCode;

    @TableField("process_code")
    private String processCode;

    @TableField("start_time")
    private LocalDateTime startTime;

    @TableField("end_time")
    private LocalDateTime endTime;

    @TableField("actual_qty")
    private Integer actualQty;

    @TableField("ng_qty")
    private Integer ngQty;

    @TableField("operator")
    private String operator;

    @TableField("equip_code")
    private String equipCode;

    @TableField("exec_status")
    private String execStatus; // 执行中/已完成

    @TableField("remark")
    private String remark;
}