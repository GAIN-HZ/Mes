package com.gxt.mesbackend.entity;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("t_equip_model") // @TableName 是用于类上的，正确
public class EquipModel {
    @TableId
    private String modelCode;
    private String modelName;
    private String spec;
    private String manageType;

    // 正确的用法：@TableField 注解用于字段上
    @TableField("is_valid")
    private String is_valid;
}