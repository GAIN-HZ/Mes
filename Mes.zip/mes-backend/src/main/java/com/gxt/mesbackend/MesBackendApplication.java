package com.gxt.mesbackend;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * MES 系统后端启动类
 * 功能：
 * 1. 标注为 Spring Boot 应用入口
 * 2. 扫描 MyBatis Mapper 接口（指定 mapper 包路径）
 */
@SpringBootApplication
@MapperScan("com.gxt.mesbackend.mapper") // 扫描所有 Mapper 接口所在的包
public class MesBackendApplication {

    public static void main(String[] args) {
        // 启动 Spring Boot 应用
        SpringApplication.run(MesBackendApplication.class, args);
    }
}