package com.gxt.mesbackend.controller;

import com.gxt.mesbackend.common.Result;
import com.gxt.mesbackend.service.MaterialOutboundService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;

@RestController
@RequestMapping("/material/outbound")
public class MaterialOutboundController {

    @Resource
    private MaterialOutboundService outboundService;

    // 生产领料出库（关联排产任务）
    @PostMapping("/production")
    public Result<?> productionOutbound(@RequestParam String scheduleCode) {
        outboundService.createProductionOutbound(scheduleCode);
        return Result.success();
    }
}