package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("t_material_check")
public class MaterialCheck {
    @TableId(type = IdType.INPUT)
    private String checkNo;            // 盘点单号（主键：CK+年月+流水号）
    @TableField("warehouse_code")
    private String warehouseCode;      // 盘点仓库编码
    @TableField("check_time")
    private LocalDateTime checkTime;   // 盘点时间
    @TableField("checker")
    private String checker;            // 盘点人
    @TableField("status")
    private String status;             // 状态（草稿/已确认/已调整）
    @TableField("remark")
    private String remark;             // 备注
}
