package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.MaterialOutboundItem;

public interface MaterialOutboundItemMapper extends BaseMapper<MaterialOutboundItem> {
}