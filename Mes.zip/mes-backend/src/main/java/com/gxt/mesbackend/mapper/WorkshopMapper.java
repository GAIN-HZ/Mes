package com.gxt.mesbackend.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.Workshop;
import org.apache.ibatis.annotations.Mapper;
@Mapper
public interface WorkshopMapper extends BaseMapper<Workshop> {
}