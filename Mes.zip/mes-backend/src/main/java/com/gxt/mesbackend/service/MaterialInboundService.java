package com.gxt.mesbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.MaterialInbound;
import com.gxt.mesbackend.vo.MaterialInboundVO;
import com.github.pagehelper.PageInfo;

public interface MaterialInboundService extends IService<MaterialInbound> {
    // 入库单分页查询
    PageInfo<MaterialInboundVO> queryPage(String inboundNo, String sourceType, Integer pageNum, Integer pageSize);

    // 确认入库（增加库存）
    void confirmInbound(String inboundNo);
}
