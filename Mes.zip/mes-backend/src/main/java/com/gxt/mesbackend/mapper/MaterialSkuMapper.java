package com.gxt.mesbackend.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.MaterialSku;
import org.apache.ibatis.annotations.Mapper;
@Mapper
public interface MaterialSkuMapper extends BaseMapper<MaterialSku> {
}