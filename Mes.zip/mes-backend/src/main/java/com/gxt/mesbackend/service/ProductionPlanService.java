package com.gxt.mesbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.ProductionPlan;
import com.gxt.mesbackend.common.Result;

public interface ProductionPlanService extends IService<ProductionPlan> {
    // 创建生产计划（包含状态校验）
    Result<?> createPlan(ProductionPlan plan);

    // 更新计划状态（如：未开始→执行中→已完成）
    Result<?> updatePlanStatus(String planCode, String status);

    // 查询指定车间/产线的计划列表
    Result<?> getPlansByLine(String lineCode, String status);
}