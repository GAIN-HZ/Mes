package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("t_material_check_item")
public class MaterialCheckItem {
    @TableId(type = IdType.ASSIGN_UUID)
    private String itemId;             // 明细ID（主键）
    @TableField("check_no")
    private String checkNo;            // 盘点单号（外键关联t_material_check）
    @TableField("material_code")
    private String materialCode;       // 物料编码
    @TableField("system_qty")
    private Integer systemQty;         // 系统库存数量
    @TableField("actual_qty")
    private Integer actualQty;         // 实际盘点数量
    @TableField("diff_qty")
    private Integer diffQty;           // 差异数量（actualQty - systemQty）
    @TableField("reason")
    private String reason;             // 差异原因
}
