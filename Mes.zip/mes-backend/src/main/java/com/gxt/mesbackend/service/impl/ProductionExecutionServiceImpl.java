package com.gxt.mesbackend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gxt.mesbackend.entity.ProductionExecution;
import com.gxt.mesbackend.mapper.ProductionExecutionMapper;
import com.gxt.mesbackend.service.ProductionExecutionService;
import com.gxt.mesbackend.common.Result;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

// 关键1：@Service 注解注册Bean，名称与控制器注入对应
@Service("productionExecutionService")
// 关键2：继承ServiceImpl（获取MyBatis-Plus默认CRUD）+ 实现自定义接口
public class ProductionExecutionServiceImpl
        extends ServiceImpl<ProductionExecutionMapper, ProductionExecution>
        implements ProductionExecutionService {

    /**
     * 开始工序执行（关联生产计划）
     */
    @Override
    public Result<?> startExecution(ProductionExecution execution) {
        // 1. 校验必填参数
        if (execution.getPlanCode() == null || execution.getPlanCode().isEmpty()) {
            return Result.fail("生产计划编码不能为空");
        }
        if (execution.getProcessCode() == null || execution.getProcessCode().isEmpty()) {
            return Result.fail("工序编码不能为空");
        }
        if (execution.getOperator() == null || execution.getOperator().isEmpty()) {
            return Result.fail("操作员不能为空");
        }

        // 2. 初始化执行信息
        execution.setStartTime(LocalDateTime.now());
        execution.setExecStatus("执行中"); // 初始状态：执行中
        execution.setActualQty(0); // 初始产量0
        execution.setNgQty(0);     // 初始不良数0

        // 3. 保存执行记录（继承ServiceImpl的save方法）
        boolean saveSuccess = save(execution);
        if (saveSuccess) {
            return Result.success(); // 返回执行ID
        } else {
            return Result.fail("工序启动失败");
        }
    }

    /**
     * 结束工序执行（更新产量、不良数等）
     */
    @Override
    public Result<?> finishExecution(String execId, Integer actualQty, Integer ngQty) {
        // 1. 校验参数
        if (execId == null || execId.isEmpty()) {
            return Result.fail("执行记录ID不能为空");
        }
        if (actualQty == null || actualQty < 0) {
            return Result.fail("实际产量不能为负数");
        }
        if (ngQty == null || ngQty < 0) {
            return Result.fail("不良数不能为负数");
        }

        // 2. 查询执行记录是否存在
        ProductionExecution execution = getById(execId);
        if (execution == null) {
            return Result.fail("执行记录不存在");
        }

        // 3. 校验状态（已完成的不能重复结束）
        if ("已完成".equals(execution.getExecStatus())) {
            return Result.fail("该执行记录已结束，无需重复操作");
        }

        // 4. 更新执行信息
        execution.setEndTime(LocalDateTime.now());
        execution.setActualQty(actualQty);
        execution.setNgQty(ngQty);
        execution.setExecStatus("已完成"); // 状态更新为：已完成

        // 5. 保存更新（继承ServiceImpl的updateById方法）
        boolean updateSuccess = updateById(execution);
        if (updateSuccess) {
            return Result.success("工序执行已结束");
        } else {
            return Result.fail("工序结束失败");
        }
    }

    /**
     * 查询指定计划的执行明细
     */
    @Override
    public Result<?> getExecutionsByPlan(String planCode) {
        // 1. 校验参数
        if (planCode == null || planCode.isEmpty()) {
            return Result.fail("生产计划编码不能为空");
        }

        // 2. 按计划编码查询执行记录（QueryWrapper条件构造）
        QueryWrapper<ProductionExecution> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("plan_code", planCode) // 匹配计划编码
                .orderByDesc("start_time"); // 按启动时间倒序

        // 3. 查询数据（继承ServiceImpl的list方法）
        return Result.success(list(queryWrapper));
    }
}