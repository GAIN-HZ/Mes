package com.gxt.mesbackend.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.util.Date;
/**
 * 员工表（t_user）
 */
@Data
@TableName("t_user")
public class User {
    @TableId(type = IdType.AUTO)
    private Integer id;           // 主键ID（自增）
    private String empCode;       // 员工编码（唯一）
    private String name;          // 员工姓名
    private String deptCode;      // 部门编码（外键）
    private String position;      // 职位
    private String status;        // 状态（在职/离职/请假）
    private Date entryDate;       // 入职日期
    private String phone;         // 联系电话
}