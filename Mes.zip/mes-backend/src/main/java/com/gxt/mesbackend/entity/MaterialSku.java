package com.gxt.mesbackend.entity;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
/**
 * 物料SKU表（t_material_sku）
 */
@Data
@TableName("t_material_sku")
public class MaterialSku {
    @TableId
    private String skuCode;    // SKU编码（主键）
    private String skuDesc;    // SKU描述
    private String is_valid;   // 是否有效（Y/N）
}