package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.MaterialCheckItem;

public interface MaterialCheckItemMapper extends BaseMapper<MaterialCheckItem> {
}