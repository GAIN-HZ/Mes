package com.gxt.mesbackend.common;
import lombok.Data;
/**
 * 统一API返回格式
 */
@Data
public class Result<T> {
    private int code;       // 状态码（200=成功，500=失败）
    private String message; // 提示信息
    private T data;         // 响应数据
    // 成功返回（带数据）
    public static <T> Result<T> success(T data) {
        Result<T> result = new Result<>();
        result.setCode(ResultCode.SUCCESS);
        result.setMessage("操作成功");
        result.setData(data);
        return result;
    }
    // 成功返回（无数据）
    public static <T> Result<T> success() {
        return success(null);
    }
    // 失败返回
    public static <T> Result<T> fail(String message) {
        Result<T> result = new Result<>();
        result.setCode(ResultCode.FAIL);
        result.setMessage(message);
        result.setData(null);
        return result;
    }
}