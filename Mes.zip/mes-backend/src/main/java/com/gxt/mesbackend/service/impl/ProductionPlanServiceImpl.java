package com.gxt.mesbackend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gxt.mesbackend.entity.ProductionPlan;
import com.gxt.mesbackend.mapper.ProductionPlanMapper;
import com.gxt.mesbackend.service.ProductionPlanService;
import com.gxt.mesbackend.common.Result;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class ProductionPlanServiceImpl extends ServiceImpl<ProductionPlanMapper, ProductionPlan>
        implements ProductionPlanService {

    @Override
    public Result<?> createPlan(ProductionPlan plan) {
        // 校验计划编码是否已存在
        if (baseMapper.selectById(plan.getPlanCode()) != null) {
            return Result.fail("计划编码已存在");
        }
        // 初始化创建信息
        plan.setCreateTime(LocalDateTime.now());
        plan.setPlanStatus("未开始"); // 默认初始状态
        baseMapper.insert(plan);
        return Result.success("计划创建成功");
    }

    @Override
    public Result<?> updatePlanStatus(String planCode, String status) {
        ProductionPlan plan = baseMapper.selectById(planCode);
        if (plan == null) {
            return Result.fail("计划不存在");
        }
        // 简单状态流转校验（可根据业务扩展）
        if ("已取消".equals(plan.getPlanStatus())) {
            return Result.fail("已取消计划不可修改状态");
        }
        plan.setPlanStatus(status);
        plan.setUpdateTime(LocalDateTime.now());
        baseMapper.updateById(plan);
        return Result.success("状态更新成功");
    }

    @Override
    public Result<?> getPlansByLine(String lineCode, String status) {
        QueryWrapper<ProductionPlan> query = new QueryWrapper<>();
        query.eq("line_code", lineCode);
        if (status != null && !status.isEmpty()) {
            query.eq("plan_status", status);
        }
        return Result.success(baseMapper.selectList(query));
    }
}