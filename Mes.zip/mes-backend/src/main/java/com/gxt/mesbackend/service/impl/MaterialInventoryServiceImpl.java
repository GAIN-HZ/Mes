package com.gxt.mesbackend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.gxt.mesbackend.entity.MaterialInventory;
import com.gxt.mesbackend.mapper.MaterialInventoryMapper;
import com.gxt.mesbackend.service.MaterialInventoryService;
import com.gxt.mesbackend.vo.MaterialInventoryVO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MaterialInventoryServiceImpl extends ServiceImpl<MaterialInventoryMapper, MaterialInventory>
        implements MaterialInventoryService {

    @Resource
    private MaterialInventoryMapper inventoryMapper;

    @Override
    public PageInfo<MaterialInventoryVO> queryPage(String materialCode, String warehouseCode, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);

        // 使用LambdaQueryWrapper替代原写法，解决语法错误
        LambdaQueryWrapper<MaterialInventory> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(materialCode != null && !materialCode.isEmpty(), MaterialInventory::getMaterialCode, materialCode)
                .eq(warehouseCode != null && !warehouseCode.isEmpty(), MaterialInventory::getWarehouseCode, warehouseCode)
                .eq(MaterialInventory::getInventoryStatus, "可用");

        List<MaterialInventory> list = inventoryMapper.selectList(wrapper);

        // 实体转VO
        List<MaterialInventoryVO> voList = list.stream().map(item -> {
            MaterialInventoryVO vo = new MaterialInventoryVO();
            BeanUtils.copyProperties(item, vo);
            return vo;
        }).collect(Collectors.toList());

        return new PageInfo<>(voList);
    }

    // 补充接口中缺失的queryWarningInventory方法实现
    @Override
    public PageInfo<MaterialInventoryVO> queryWarningInventory(Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);

        // 调用Mapper的库存预警查询方法
        List<MaterialInventory> list = inventoryMapper.selectWarningInventory();

        // 实体转VO
        List<MaterialInventoryVO> voList = list.stream().map(item -> {
            MaterialInventoryVO vo = new MaterialInventoryVO();
            BeanUtils.copyProperties(item, vo);
            return vo;
        }).collect(Collectors.toList());

        return new PageInfo<>(voList);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deductStock(String materialCode, String warehouseCode, Integer qty) {
        // 校验参数
        if (materialCode == null || materialCode.isEmpty() || warehouseCode == null || warehouseCode.isEmpty() || qty == null || qty <= 0) {
            throw new RuntimeException("参数无效");
        }

        MaterialInventory inventory = inventoryMapper.selectByMaterialAndWarehouse(materialCode, warehouseCode);
        if (inventory == null) {
            throw new RuntimeException("物料库存不存在");
        }
        if (inventory.getStockQty() < qty) {
            throw new RuntimeException("库存不足，当前库存：" + inventory.getStockQty());
        }

        inventory.setStockQty(inventory.getStockQty() - qty);
        inventoryMapper.updateById(inventory);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addStock(String materialCode, String warehouseCode, Integer qty) {
        // 校验参数
        if (materialCode == null || materialCode.isEmpty() || warehouseCode == null || warehouseCode.isEmpty() || qty == null || qty <= 0) {
            throw new RuntimeException("参数无效");
        }

        MaterialInventory inventory = inventoryMapper.selectByMaterialAndWarehouse(materialCode, warehouseCode);
        if (inventory == null) {
            // 新增库存记录
            inventory = new MaterialInventory();
            inventory.setMaterialCode(materialCode);
            inventory.setWarehouseCode(warehouseCode);
            inventory.setStockQty(qty);
            inventory.setInventoryStatus("可用");
            inventoryMapper.insert(inventory);
        } else {
            // 更新库存
            inventory.setStockQty(inventory.getStockQty() + qty);
            inventoryMapper.updateById(inventory);
        }
    }
}