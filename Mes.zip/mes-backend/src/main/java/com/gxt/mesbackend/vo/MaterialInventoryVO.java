package com.gxt.mesbackend.vo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class MaterialInventoryVO {
    private String inventoryId;        // 库存记录ID
    private String materialCode;       // 物料编码
    private String materialName;       // 物料名称（关联t_material）
    private String warehouseCode;      // 仓库编码
    private String warehouseName;      // 仓库名称（关联t_warehouse）
    private Integer stockQty;          // 当前库存数量
    private Integer safeStockQty;      // 安全库存数量
    private String batchNo;            // 批次号
    private LocalDateTime produceDate; // 生产/入库日期
    private LocalDateTime expireDate;  // 过期日期
    private String inventoryStatus;    // 库存状态
}