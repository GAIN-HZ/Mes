package com.gxt.mesbackend.entity;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
/**
 * 物料表（t_material）
 */
@Data
@TableName("t_material")
public class Material {
    @TableId
    private String materialCode;     // 物料编码（主键）
    private String materialName;     // 物料名称
    private String spec;             // 物料规格
    private String skuCode;          // SKU编码（外键）
    private String moistureLevelCode;// 湿敏级别编码（外键）
    private String shelfLifeCode;    // 保质期方案编码（外键）
    private String warehouseCode;    // 仓库编码（外键）
}