package com.gxt.mesbackend.controller;
import com.gxt.mesbackend.common.Result;
import com.gxt.mesbackend.entity.Department;
import com.gxt.mesbackend.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/**
 * 部门管理接口
 */
@RestController
@RequestMapping("/basic/department")
public class DepartmentController {
    @Autowired
    private DepartmentService departmentService;
    /**
     * 新增部门
     */
    @PostMapping("/add")
    public Result<?> add(@RequestBody Department department) {
        boolean saved = departmentService.save(department);
        return saved ? Result.success() : Result.fail("新增失败");
    }
    /**
     * 删除部门
     */
    @DeleteMapping("/{deptCode}")
    public Result<?> delete(@PathVariable String deptCode) {
        boolean removed = departmentService.removeById(deptCode);
        return removed ? Result.success() : Result.fail("删除失败");
    }
    /**
     * 更新部门
     */
    @PutMapping("/update")
    public Result<?> update(@RequestBody Department department) {
        boolean updated = departmentService.updateById(department);
        return updated ? Result.success() : Result.fail("更新失败");
    }
    /**
     * 查询所有部门
     */
    @GetMapping("/list")
    public Result<List<Department>> list() {
        return Result.success(departmentService.list());
    }
    /**
     * 根据ID查询部门
     */
    @GetMapping("/{deptCode}")
    public Result<Department> getById(@PathVariable String deptCode) {
        Department department = departmentService.getById(deptCode);
        return department != null ? Result.success(department) : Result.fail("部门不存在");
    }
}