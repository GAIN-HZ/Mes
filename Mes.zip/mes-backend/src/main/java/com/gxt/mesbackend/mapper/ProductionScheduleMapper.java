package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.ProductionSchedule;
import org.apache.ibatis.annotations.Mapper;

/**
 * 生产排产任务Mapper（关联t_production_schedule表）
 */
@Mapper // 若项目使用@MapperScan可省略此注解
public interface ProductionScheduleMapper extends BaseMapper<ProductionSchedule> {
    // 继承BaseMapper后，无需手动定义基础CRUD方法（MyBatis-Plus自动实现）
}