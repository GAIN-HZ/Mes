package com.gxt.mesbackend.controller;
import com.gxt.mesbackend.common.Result;
import com.gxt.mesbackend.entity.EquipInfo;
import com.gxt.mesbackend.service.EquipInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/**
 * 设备信息管理接口
 */
@RestController
@RequestMapping("/basic/equip")
public class EquipInfoController {
    @Autowired
    private EquipInfoService equipInfoService;
    /**
     * 新增设备
     */
    @PostMapping("/add")
    public Result<?> add(@RequestBody EquipInfo equipInfo) {
        boolean saved = equipInfoService.save(equipInfo);
        return saved ? Result.success() : Result.fail("新增失败");
    }
    /**
     * 删除设备
     */
    @DeleteMapping("/{equipCode}")
    public Result<?> delete(@PathVariable String equipCode) {
        boolean removed = equipInfoService.removeById(equipCode);
        return removed ? Result.success() : Result.fail("删除失败");
    }
    /**
     * 更新设备
     */
    @PutMapping("/update")
    public Result<?> update(@RequestBody EquipInfo equipInfo) {
        boolean updated = equipInfoService.updateById(equipInfo);
        return updated ? Result.success() : Result.fail("更新失败");
    }
    /**
     * 查询所有设备
     */
    @GetMapping("/list")
    public Result<List<EquipInfo>> list() {
        return Result.success(equipInfoService.list());
    }
    /**
     * 根据设备编码查询
     */
    @GetMapping("/{equipCode}")
    public Result<EquipInfo> getById(@PathVariable String equipCode) {
        EquipInfo equipInfo = equipInfoService.getById(equipCode);
        return equipInfo != null ? Result.success(equipInfo) : Result.fail("设备不存在");
    }
}