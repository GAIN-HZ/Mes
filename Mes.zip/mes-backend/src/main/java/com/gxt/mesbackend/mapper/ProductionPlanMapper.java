package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.ProductionPlan;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductionPlanMapper extends BaseMapper<ProductionPlan> {
    // 继承BaseMapper后，默认包含CRUD方法，可自定义复杂查询
}