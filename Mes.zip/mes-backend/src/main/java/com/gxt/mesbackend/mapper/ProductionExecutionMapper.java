package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.ProductionExecution;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductionExecutionMapper extends BaseMapper<ProductionExecution> {
    // 可扩展按计划编码查询执行记录等方法
}
