package com.gxt.mesbackend.common;
/**
 * 响应状态码
 */
public class ResultCode {
    public static final int SUCCESS = 200; // 成功
    public static final int FAIL = 500;    // 失败
    public static final int PARAM_ERROR = 400; // 参数错误
    public static final int NOT_FOUND = 404;   // 资源不存在
}