package com.gxt.mesbackend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gxt.mesbackend.entity.ProductionSchedule;
import com.gxt.mesbackend.vo.ProductionScheduleVO;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface ProductionScheduleService extends IService<ProductionSchedule> {
    /**
     * 分页查询排产任务
     */
    PageInfo<ProductionScheduleVO> queryPage(String scheduleCode, String planCode, Integer pageNum, Integer pageSize);

    /**
     * 根据排产任务编码查询详情
     */
    ProductionSchedule getByScheduleCode(String scheduleCode);

    /**
     * 根据生产计划编码查询排产任务
     */
    List<ProductionSchedule> getByPlanCode(String planCode);

    /**
     * 创建排产任务
     */
    void createSchedule(ProductionSchedule schedule);

    /**
     * 更新排产任务状态
     */
    void updateStatus(String scheduleCode, String status);
}
