package com.gxt.mesbackend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gxt.mesbackend.entity.MaterialOutbound;
import org.apache.ibatis.annotations.Param;

public interface MaterialOutboundMapper extends BaseMapper<MaterialOutbound> {
    // 查询指定前缀的最大流水号
    Integer selectMaxCode(@Param("prefix") String prefix);
}