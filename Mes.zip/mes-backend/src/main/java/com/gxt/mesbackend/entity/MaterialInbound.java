package com.gxt.mesbackend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("t_material_inbound")
public class MaterialInbound {
    @TableId(type = IdType.INPUT)
    private String inboundNo;          // 入库单号（主键：IN+年月+流水号）
    @TableField("source_type")
    private String sourceType;         // 入库来源（采购/生产完工/退货）
    @TableField("source_no")
    private String sourceNo;           // 来源单号（采购单号/生产计划号）
    @TableField("warehouse_code")
    private String warehouseCode;      // 入库仓库编码
    @TableField("inbound_time")
    private LocalDateTime inboundTime; // 入库时间
    @TableField("total_qty")
    private Integer totalQty;          // 入库总数量
    @TableField("operator")
    private String operator;           // 操作员
    @TableField("status")
    private String status;             // 状态（草稿/已确认/已取消）
    @TableField("remark")
    private String remark;             // 备注
}
