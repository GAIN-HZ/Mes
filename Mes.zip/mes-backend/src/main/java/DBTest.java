import java.sql.Connection;
import java.sql.DriverManager;

public class DBTest {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mes_data_administration?useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true";
        String user = "root";
        String password = "12345";
        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            System.out.println("连接成功！");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}